##
##This classes creates a connection object of a SGBD type
##Paramentes passed: SGBD(mysql), conn ipt(127.0.0.1 default), 
##

<?php

class Conn{

	private $conn_sgbd;
	private $conn_conn;
	private $conn_user;
	private $conn_pwd;

##Constructors
	##Complete
	function __construct($sgbd, $conn, $user, $pwd){
		try{
			if($conn = new PDO("{$sgbd}:host={$conn}",$user,$pwd)){
				$this->conn_sgbd = $sgbd;
				$this->conn_conn = $conn;
				$this->conn_user = $user;
				$this->conn_pwd = $pwd;
				return true;
			}
		}catch(PDOException $e){
			return false;
		}
	}
	##Localhost Default
	function __construct($sgbd, $user, $pwd){
		try{
			if($conn = new PDO("{$sgbd}:host=127.0.0.1",$user,$pwd)){
				$this->conn_sgbd = $sgbd;
				$this->conn_conn = '127.0.0.1';
				$this->conn_user = $user;
				$this->conn_pwd = $pwd;
				return true;
			}
		}catch(PDOException $e){
			return false;
		}
	}
	##User and Password default
	function __construct($sgbd){
		try{
			if($conn = new PDO("{$sgbd}:host=127.0.0.1",$user,$pwd)){
				$this->conn_sgbd = $sgbd;
				$this->conn_conn = '127.0.0.1';
				$this->conn_user = "root";
				$this->conn_pwd = "root";
				return true;
			}
		}catch(PDOException $e){
			return false;
		}
	}

##Functions
	public function selectDb(){
		echo "We're here!";
	}
}
?>
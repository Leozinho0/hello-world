<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Index</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<style>
		#div_conn{
			border: 1px solid grey;
			border-radius: 5px;
			padding: 15px;
			margin: 0 auto;
			background-color: #ccddff;
			width: 400px;
		}
		#div_error{
			text-align: center;
			display: none;
			color: #D8000C;
   			background-color: #FFBABA;
   			width: 400px;
   			margin: 0 auto;
   			margin-top: 15px;
   			padding: 15px;
   			border: 1px solid;
		}
	</style>
</head>
<body>
	<div id="div_conn">
		<div>
			<span>Banco</span>
			<select name="cb_banco" id="">
				<option value="mysql">
					MySql
				</option>
			</select>
		</div>
		<div>
			<span>Conexao</span>
			<input type="text" value="127.0.0.1" id="conn">
		</div>
		<div>
			<span>Usuario</span>
			<input type="text" id="user">
		</div>
		<div>
			<span>Senha</span>
			<input type="password" id="pwd">
		</div>
		<div style="text-align:center; margin-top: 10px;">
			<input type="button" value="Conectar" onclick="f_conn();">
		</div>
	</div>
	<div id="div_error">
		<span>Dados Inválidos!</span>
	</div>

	<script>
		function f_conn(){
			dd = 'conn=' + document.getElementById('conn').value + '&user=' + document.getElementById('user').value + '&pwd=' + document.getElementById('pwd').value;
			$.ajax({
				type: 'POST',
				url: 'valid_conn.php',
				data: dd,
				success: function(ds){
					if(ds == "conn"){
						$.ajax({
							type: '',
							url: '',
							data: '',
							success: function(){
								
							}
						});

					}else if(ds == "notconn"){
						$("#div_error").show();
					}
				}
			});
		}
	</script>
</body>
</html>
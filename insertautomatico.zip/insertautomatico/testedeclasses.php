<?php

include 'conn.class.php';

$conn = new Conn("mysql", "root", "root");
if($conn){
	echo "Workd!";
}

?>
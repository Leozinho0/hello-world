<?php
if(isset($_POST['conn']) && isset($_POST['user']) && isset($_POST['pwd'])){
	try{
		if($conn = new PDO("mysql:host={$_POST['conn']}",$_POST['user'],$_POST['pwd'])){
			echo "conn";
		}}catch(PDOException $e){
		echo "notconn";
	}
}
?>
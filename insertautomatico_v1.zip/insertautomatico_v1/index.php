<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<script src="js/jquery.js"></script>
	<style>
		body{
			margin: 0;
			background-color: #cce6ff;
		}
		.box_center{
			background-color: #ddccff;
			margin: 10px auto;
			border-radius: 5px;
			border: 1px solid  #ccb3ff;
			padding: 10px;
			width: 400px;
		}
		table td{
			border: 1px solid;
		}
	</style>
</head>
<body>
	<div class="box_center">
		<div>
			<table>
				<tr>
					<td>SGBD</td>
					<td>
						<select>
							<option value="mysql" id="conn_sgbd">MySQL</option>
						</select>
					</td>
				</tr>
			</table>
		</div>
		<div>
			<table>
				<tr>
					<td>Conexão</td>
					<td>
						<input type="text" value="127.0.0.1" id="conn_adress">
					</td>
				</tr>
			</table>
		</div>
		<div>
			<table>
				<tr>
					<td>Usuario</td>
					<td>
						<input type="text" id="conn_user">
					</td>
				</tr>
			</table>
		</div>
		<div>
			<table>
				<tr>
					<td>Senha</td>
					<td>
						<input type="password" id="conn_password">
					</td>
				</tr>
			</table>
		</div>
		<div>
			<input type="button" value="Conectar" onclick="js_conn();">
		</div>
	</div>
	<div class="box_center" id="div_dados" style="display:none;">
		<div id="div_bases" style="display:none;">
			<table>
				<tr>
					<td>Base</td>
					<td>
						<select id="id_bases" onchange="js_listTables();">
						</select>
					</td>
				</tr>
			</table>
		</div>
		<div id="div_tabelas" style="display:none;">
			<table>
				<tr>
					<td>Tabela</td>
					<td>
						<select id="id_tables">
							
						</select>
					</td>
				</tr>
			</table>
		</div>
		<div>
			<table>
				<tr>
					<td>QT de registos</td>
					<td>
						<select name="" id="qtd_insert">
							<option value="1" selected>1</option>
							<option value="5">5</option>
							<option value="10">10</option>
							<option value="15">15</option>
							<option value="20">20</option>
							<option value="25">25</option>
							<option value="50">50</option>
							<option value="100">100</option>
							<option value="200">200</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<input type="button" value="Inserir!" onclick="js_insert();">
					</td>
				</tr>
			</table>
		</div>
	</div>
	<script>
		function js_listBases(){
			var d = 'sgbd=' + document.getElementById("conn_sgbd").value + '&adress=' + document.getElementById("conn_adress").value + '&user=' + document.getElementById("conn_user").value + '&password=' + document.getElementById("conn_password").value + "&id=2";
			$.ajax({
				type: 'POST',
				url: 'conn_valid.php',
				data: d,
				success: function(ds){
					arr = JSON.parse(ds);

					$("#id_bases").html('');

					$("#id_bases").append("<option value=''></option>");
					for(it=0; it<arr.length; it++)
					{
						$("#id_bases").append("<option value='"+ arr[ it ].Database +"'>"+ arr[ it ].Database +"</option>");
					}

					$('#div_dados').show();
					$('#div_bases').show();
				}
			});
		}
	</script>
	<script>
		function js_listTables(){
			var d = 'sgbd=' + document.getElementById("conn_sgbd").value + '&adress=' + document.getElementById("conn_adress").value + '&user=' + document.getElementById("conn_user").value + '&password=' + document.getElementById("conn_password").value + "&base=" + document.getElementById("id_bases").value + "&id=3";
			$.ajax({
				type: 'POST',
				url: 'conn_valid.php',
				data: d,
				success: function(ds){
					arr = JSON.parse(ds);

					$("#id_tables").html('');
					for(it=0; it<arr.length; it++)
					{
						$("#id_tables").append("<option value='"+ arr[it][0] +"'>"+ arr[it][0] +"</option>");
					}
					$('#div_tabelas').show();
				}
			});
		}
	</script>
	<!--ESTOU AQUI
	ESTOU AQUI
	ESTOU AQUI
	ESTOU AQUI
	ESTOU AQUI
	ESTOU AQUI
	ESTOU AQUI
	ESTOU AQUI
	ESTOU AQUI
	ESTOU AQUI
	ESTOU AQUI -->
	<script>
		function js_insert(){
			var d = 'sgbd=' + document.getElementById("conn_sgbd").value + '&adress=' + document.getElementById("conn_adress").value + '&user=' + document.getElementById("conn_user").value + '&password=' + document.getElementById("conn_password").value + "&base=" + document.getElementById("id_bases").value + "&table=" + document.getElementById("id_tables").value + "&qtd=" + document.getElementById("qtd_insert").value +"&id=4";
			$.ajax({
				type: 'POST',
				url: 'conn_valid.php',
				data: d,
				success: function(ds){
					alert(ds);
				}
			});
		}
	</script>
	<script>
		function js_conn(){
			var d = 'sgbd=' + document.getElementById("conn_sgbd").value + '&adress=' + document.getElementById("conn_adress").value + '&user=' + document.getElementById("conn_user").value + '&password=' + document.getElementById("conn_password").value + "&id=1";
			$.ajax({
				type: 'POST',
				url: 'conn_valid.php',
				data: d,
				success: function(ds){
					if(ds == "y"){
						//$("#div_bases").show();
						js_listBases();
					}else {
						alert(ds);
					}
				}
			});
		}
	</script>
</body>
</html>
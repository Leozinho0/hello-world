<?php

include 'conn.class.php';

$conn = new Conn("mysql", "127.0.0.1", "root", "root");
$conn->getConn();


?>
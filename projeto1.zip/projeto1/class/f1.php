<?php






function f1(){
	echo "lala";
}



if(function_exists(f1())){
	echo "lala";
}


?>
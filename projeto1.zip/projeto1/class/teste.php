<?php
session_start();
$_SESSION['leo'] = 'leo';

if(true):
	echo 'oi';
else:
	echo 'nop';
	echo 'nop2';
	echo 'nop';
	echo 'nop2';
	echo 'nop';
	echo 'nop2';
	echo 'nop';
	echo 'nop2';
	echo 'nop';
	echo 'nop2';
	echo 'nop';
	echo 'nop2';
	echo 'nop';
	echo 'nop2';
	echo 'nop';
	echo 'nop2';
	echo 'nop';
	echo 'nop2';
	echo 'nop';
	echo 'nop2';
endif;
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<section>
		<input type="button" onclick="window.location = 'mostrar_cookie.php';" value="Press">
	</section>
</body>
</html>








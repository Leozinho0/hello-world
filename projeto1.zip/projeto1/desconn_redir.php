<?php
$index_page = "index.php";

    echo "<link rel='stylesheet' type='text/css' href='css/style2.css'>";
    echo "<div class='container_sessionExpired'>";
    echo "<h3>";
    echo "Sessão Expirada";
    echo "</h3>";
    echo "<button onclick=window.location='".$index_page."'>Ok</button>";
    echo "</div>";
?>
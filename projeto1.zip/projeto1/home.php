<?php
session_start();
//Includes
require_once 'class/conn.class.php';
require_once 'html_functions.php';

if(isset($_SESSION['conn']['status']) && $_SESSION['conn']['status'] === true){
    $conn = new Conn($_SESSION['conn']['banco'], $_SESSION['conn']['address'], $_SESSION['conn']['usr'], $_SESSION['conn']['psw']);
    $arr_databases = array();
    $arr_databases = $conn->showDatabases($_SESSION['conn']['banco']);
    //
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Home</title>
        <style>
            body, html{
                margin: 0;
                padding: 0;
                height: 100%;
                //background-color: grey;
            }
            .left_container{
                //background-color: blue;
                position: fixed;
                width: 250px;
                height: 100%;
            }   
            .right_container{
                //background-color: purple;
                position: fixed;
                width: 100%;
                height: 100%;
                margin-left: 250px;
            }
            #header_left_container{
                background-color: red;
                width: 100%;
                height: 50px;
            }
            #header_right_container{
                background-color: grey;
                width: 100%;
                height: 50px;
            }
            #body_left_container{
                //background-color: yellow;
                width: 100%;
                height: 100%;
                overflow: scroll;
                white-space: nowrap;
            }
            #body_right_container{
                //background-color: green;
                width: 100%;
                height: 100%;
                overflow: scroll;
            }
            .ul_tables{
                 list-style: none;
                 padding: 0;
                 margin-left: 15px;
            }
            a{
                cursor: pointer;
            }
        </style>
        <script src="js/scripts.js"></script>
        <script src="js/jquery.js"></script>
    </head>
    <body>
        <div class="left_container">
            <div id="header_left_container">
                Left Toolbar Container
            </div>
            <div id="body_left_container">
                <?php
                html_databases($arr_databases);
                ?>
            </div>
        </div>
        <div class="right_container">
            <div id="header_right_container">
                Right Toolbar Container
            </div>
            <div id="body_right_container">
            </div>
        </div>
    </body>
    </html>
    <?php
}
else{
    include "desconn_redir.php";
}
?>